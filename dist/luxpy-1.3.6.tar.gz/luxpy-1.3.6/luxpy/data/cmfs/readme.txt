CMFs 1931_2, 1964_10, 2006_2 and 2006_10 were downloaded from cvrl.org on June 17, 2017 at 15:24
CMFs 1931_2_judd, 1931_2_juddvos and the 1951_20_scotopic V' were downloaded from cvrl.org on April 17, 2018 at 8:23


Notes:
1.
All functions have been expanded using zeros to a full 360-830 range. 
This way those wavelengths do not contribute in the calculation, AND are not extrapolated using the closest known value as per CIE recommendation.

2.
The 1951 scoptopic V' function has been replicated in the 3 xbar, ybar, zbar columns to obtain a data format similar to the photopic
color matching functions. This way V' can be called in exactly the same way as other V functions can be called from the X,Y,Z cmf sets.
